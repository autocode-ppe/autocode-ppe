DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `idq` int(3) NOT NULL AUTO_INCREMENT,
  `libelleQ` varchar(255) NOT NULL,
  `niveau` int(11) NOT NULL,
  PRIMARY KEY (`idq`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `questions`
--

INSERT INTO `questions` (`idq`, `libelleQ`, `niveau`) VALUES
(2, 'Pour tourner à gauche je reste sur cette voie', 0),
(1, 'Je me suis trompé de direction, je peux effectuer une marche arrière', 1),
(3, 'Ces piétons souhaitent traverser', 0),
(4, 'Je suis bien placé pour continuer tout droit', 1),
(5, 'Je cède le passage', 0),
(6, 'La voie de droite est réservée aux cyclomoteurs', 1),
(7, 'Il est préférable que la personne qui raccompagne ses amis après une fête arrosée soit: désignée à la fin de la fête', 0),
(8, 'Dans ce giratoire je souhaite me rendre sur l’autoroute, je prends', 1),
(9, 'La voiture d"en face a le feu rouge. Pour tourner à gauche', 0),
(10, 'Dans cette situation', 1),
(11, 'Je suis à hauteur d’une sortie autoroutière', 0),
(12, 'Je vais rencontrer', 0),
(13, 'La chaussée va être rétrécie par la droite', 1),
(14, 'Ce panneau est un panneau de', 0),
(15, 'Je dépasse immédiatement', 1),
(16, 'Sur cette chaussée je me place', 1),
(17, 'En prenant à droite, je quitte', 0),
(18, 'La rue en face est à sens unique', 0),
(19, 'Je passe', 1),
(20, 'Dans cette situation', 0);


-- --------------------------------------------------------

--
-- Structure de la table `reponses`
--

DROP TABLE IF EXISTS `reponses`;
CREATE TABLE IF NOT EXISTS `reponses` (
  `idr` int(3) NOT NULL AUTO_INCREMENT,
  `idq` int(3) NOT NULL,
  `libeller` varchar(255) NOT NULL,
  `verite` tinyint(1) NOT NULL,
  PRIMARY KEY (`idr`)
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponses`
--

INSERT INTO `reponses` (`idr`, `idq`, `libeller`, `verite`) VALUES
(6, 2, 'Oui', 0),
(5, 2, 'Non', 1),
(4, 1, 'Oui', 0),
(2, 1, 'Non', 1),
(9, 3, 'Je passe', 1),
(10, 3, 'Je m"arrete', 0),
(15, 4, 'Non', 0),
(16, 4, 'Oui', 1),
(17, 5, 'Non', 1),
(18, 5, 'Oui', 0),
(21, 6, 'Non', 1),
(22, 6, 'Oui', 0),
(25, 7, 'Oui', 0),
(26, 7, 'Non', 1),
(29, 8, 'LA PREMIERE SORTIE', 1),
(30, 8, 'LA DEUXIEME SORTIE', 0),
(35, 9, 'JE PASSE AVANT LA VOITURE ROUGE', 1),
(36, 9, 'JE PASSE APRES LA VOITURE ROUGE', 0),
(39, 10, 'JE DIMINUE MA DISTANCE DE SECURITE', 0),
(40, 10, 'J’AUGMENTE MA DISTANCE DE SECURITE', 1),
(43, 11, 'Oui', 1),
(44, 11, 'Non', 0),
(45, 12, 'DES ENFANTS', 0),
(46, 12, 'UNE DESCENTE DANGEREUSE', 1),
(49, 13, 'Non', 1),
(50, 13, 'Oui', 0),
(55, 14, 'DANGER', 1),
(56, 14, 'INTERDICTION', 0),
(59, 15, 'Oui', 0),
(60, 15, 'Non', 1),
(61, 16, 'le long de la ligne médiane', 0),
(62, 16, 'le long de la bande cyclable', 1),
(63, 16, 'peu importe', 0),
(65, 17, 'Une autoroute', 1),
(66, 17, 'Une route à accès réglementé', 0),
(67, 17, 'Une route prioritaire', 0),
(69, 18, 'Oui', 0),
(71, 18, 'Non', 1),
(74, 19, 'avant la voiture rouge', 1),
(75, 19, 'après la voiture rouge', 0),
(79, 20, 'JE PASSE ', 0),
(80, 20, 'JE M’ARRETE', 1);
COMMIT;