<?php
    session_start();
    
    
   
?>

<!DOCTYPE html>
<html>
<head>
	<title>Auto&Code</title>
	<link rel="stylesheet" type="text/css" href="autoecole.css">

</head>

<body>

<header class="main-head">
        <div class="row">
                <div class="logo">
                        <img src="image/logo4.png"/>
                
                        <ul class="main-nav">
                                <li class="active"><a href="Acceuil.php">Home</a></li>
                                <li><a href="php/connexion.php">Identification</a></li>
                                <li><a href="php/deconnexion.php">Deconnexion</a></li>
                        <ul>

                </div>


                <div class="hero">
                        <h1 class="h1-hero"> Auto&Code </h1>

                        <div class="button">
                                <a href="" class="btn btn-one">Contacts</a>
                                <a href="" class="btn btn-two">Plus d'infos</a>

                        </div>
                 


                </div>
        </div>

</header>


</body>
</html>