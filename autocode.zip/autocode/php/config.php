<?php
   $bdd = mysqli_connect("localhost", "matteo", "matteo", "autocode");
   if(!$bdd){
       echo "Database connected" . mysqli_connect_error();
   }
