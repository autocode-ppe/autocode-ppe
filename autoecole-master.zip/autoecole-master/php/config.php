<?php
   /*$bdd = mysqli_connect("localhost", "Adrien", "Adrien", "autocode");
   if(!$bdd){
       echo "Database connected" . mysqli_connect_error();
   }
?>*/
   $bdd = mysqli_connect("127.0.0.1","root", "", "autocode");
   if(!$bdd){
       echo "Database connected" . mysqli_connect_error();
   }
   ?>