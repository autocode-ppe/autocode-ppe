<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planning</title>
	<link rel="stylesheet" type="text/css" href="planning.css">
</head>
<body>
    
    <center>
        <div>
        <h1>Planning</h1>
        <iframe src="https://calendar.google.com/calendar/embed?height=600&wkst=1&bgcolor=%237986CB&ctz=Europe%2FParis&src=YWxsZXJtYWRyaWQxNzAwQGdtYWlsLmNvbQ&src=c2dhamVnM3F1cXJ2YmUzOGVnZjYyNmVqdDBAZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbQ&src=ZnIuZnJlbmNoI2hvbGlkYXlAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&color=%23039BE5&color=%234285F4&color=%230B8043" style="border:solid 1px #777" width="800" height="600" frameborder="0" scrolling="no"></iframe>  
        </div>
    </center>
    
</body>
</html>