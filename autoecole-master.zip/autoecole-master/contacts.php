<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts</title>

</head>
<body>

<div data-role="header">
    <h1>Contacts</h1>
    <a id="bars-button" data-icon="bars" class="ui-btn-right" style="margin-top:10px;" href="Accueil.php">Accueil</a>
</div><!-- /header -->


      <!-- Ici le contenu -->
<div data-role="content">	
<div class="container">
        <div class="hero-unit"> 
            <div class="row-fluid">
                <div class="span6">

                <h2> Contact </h2>

                <p> 27 boulevard du Général-de-Gaulle <p> 83100 Toulon Cedex </p>
                <a href="mailto:contact@auto&code.com">contact@auto&code.com</a>
                <p> 01 39 52 75 69 </p>
                

                <hr size="3" color="black">
                <h3> Horaires d'ouverture du bureau :</h3>
                
                <p> Du Lundi au Vendredi : 9h-13h  14h-18h <p>
                    Samedi : 9h-13h </p>

                <hr size="3" color="black">	
                <h3> Séances de code :</h3>
                
                
                <p>	Lundi : 15h-19h <p>
                    Mardi : 9h-12h  14h-18h <p>
                    Mercredi : 9h-12h  14h-19h <p>
                    Jeudi : 9h-12h  14h-20h <p>
                    Vendredi : 9h-12h  14h-18h <p>
                    Samedi : 9h-12h <p>

                    <p> (toute les heures) </p>


                </p>
                </div>

                <div class="span6">  
                    <iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.fr/maps?f=q&amp;source=s_q&amp;hl=fr&amp;geocode=&amp;q=27+boulevard+du+G%C3%A9n%C3%A9ral-de-Gaulle+83100+Toulon+&amp;sll=48.850364,2.340662&amp;sspn=0.072406,0.195179&amp;ie=UTF8&amp;hq=&amp;hnear=27+Corniche+du+G%C3%A9n%C3%A9ral+de+Gaulle,+83000+Toulon,+Var,+Provence-Alpes-C%C3%B4te+d'Azur&amp;t=m&amp;z=14&amp;ll=43.108676,5.953992&amp;output=embed"></iframe><p><small><a href="https://maps.google.fr/maps?f=q&amp;source=embed&amp;hl=fr&amp;geocode=&amp;q=27+boulevard+du+G%C3%A9n%C3%A9ral-de-Gaulle+83100+Toulon+&amp;sll=48.850364,2.340662&amp;sspn=0.072406,0.195179&amp;ie=UTF8&amp;hq=&amp;hnear=27+Corniche+du+G%C3%A9n%C3%A9ral+de+Gaulle,+83000+Toulon,+Var,+Provence-Alpes-C%C3%B4te+d'Azur&amp;t=m&amp;z=14&amp;ll=43.108676,5.953992" style="color:#0000FF;text-align:left">Agrandir le plan</a></small>

                    <p> <p>

                </div> 
            </div>		
        </div>
    </div>	
    
      <!-- Fin du contenu -->




<div data-role="footer">
    <h4>Tous droits réservés</h4>
</div><!-- /footer -->
</div><!-- /page -->

</body>
</html>