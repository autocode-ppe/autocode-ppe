-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 27 mai 2022 à 08:55
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `autocode`
--
drop database if exists autocode;
create database autocode;
use autocode;
-- --------------------------------------------------------

--
-- Structure de la table `eleve`
--

DROP TABLE IF EXISTS `eleve`;
CREATE TABLE IF NOT EXISTS `eleve` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`nom` varchar(255) NOT NULL,
`prenom` varchar(255) NOT NULL,
`datenaiss` date NOT NULL,
`email` varchar(255) NOT NULL,
`phone` varchar(20) NOT NULL,
`adresse` varchar(255) NOT NULL,
`ville` varchar(255) NOT NULL,
`codeP` int(255) NOT NULL,
`mdp` varchar(255) NOT NULL,
`img` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `eleve`
--

INSERT INTO `eleve` (`id`, `nom`, `prenom`, `datenaiss`, `email`, `phone`, `adresse`, `ville`, `codeP`, `mdp`, `img`) VALUES
(1, 'kaye', 'hubert', '2022-04-06', 'kayeromy@gmail.com', '07 82 81 86 24', '5 rue henri barbusse', 'clichy', 92110, 'azert', '1649056757advertisement.png'),
(2, 'Dupond', 'FRED', '2000-01-01', 'Duponde@gmail.com', '06 51 09 05 04', '5 rue potier', 'Paris', 75017, 'azertyuiop', '1650014497bg_banner.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `examp`
--

DROP TABLE IF EXISTS `examp`;
CREATE TABLE IF NOT EXISTS `examp` (
`IdP` int(3) NOT NULL,
`dateP` date DEFAULT NULL,
`HeureDP` date DEFAULT NULL,
`HeureFP` date DEFAULT NULL,
`ResultatP` varchar(25) DEFAULT NULL,
PRIMARY KEY (`IdP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `logs`
--

DROP TABLE IF EXISTS `logs`;
CREATE TABLE IF NOT EXISTS `logs` (
`ide` int(10) NOT NULL AUTO_INCREMENT,
`DateDebut` datetime NOT NULL,
`DateFin` datetime DEFAULT NULL,
`Login` varchar(25) NOT NULL,
PRIMARY KEY (`ide`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `moniteurs`
--

DROP TABLE IF EXISTS `moniteurs`;
CREATE TABLE IF NOT EXISTS `moniteurs` (
`idM` int(3) NOT NULL,
`nomM` varchar(25) NOT NULL,
`prenomM` varchar(25) NOT NULL,
`numM` char(10) NOT NULL,
`dateE` date DEFAULT NULL,
`mailM` varchar(25) NOT NULL,
`diplome` varchar(25) DEFAULT NULL,
PRIMARY KEY (`idM`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `plannig`
--

DROP TABLE IF EXISTS `plannig`;
CREATE TABLE IF NOT EXISTS `plannig` (
`IdCond` int(3) NOT NULL,
`IdM` int(3) NOT NULL,
`IdCode` int(3) NOT NULL,
`IdE` int(3) NOT NULL,
`Etatp` varchar(25) DEFAULT NULL,
`DateHF` date DEFAULT NULL,
PRIMARY KEY (`IdCond`,`IdM`,`IdCode`,`IdE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
`idq` int(3) NOT NULL AUTO_INCREMENT,
`libelleQ` varchar(255) NOT NULL,
`niveau` int(11) NOT NULL,
PRIMARY KEY (`idq`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `questions`
--

INSERT INTO `questions` (`idq`, `libelleQ`, `niveau`) VALUES
(2, 'Pour tourner a gauche je reste sur cette voie', 0),
(1, 'Je me suis trompe de direction, je peux effectuer une marche arriere', 1),
(3, 'Ces pietons souhaitent traverser', 0),
(4, 'Je suis bien place pour continuer tout droit', 1),
(5, 'Je cede le passage', 0),
(6, 'La voie de droite est reservee aux cyclomoteurs', 1),
(7, 'Il est preferable que la personne qui raccompagne ses amis apres une fete arrosee soit: designee a la fin de la fete', 0),
(8, 'Dans ce giratoire je souhaite me rendre sur l autoroute, je prends', 1),
(9, 'La voiture d en face a le feu rouge. Pour tourner a gauche', 0),
(10, 'Dans cette situation', 1),
(11, 'Je suis a hauteur d une sortie autoroutiere', 0),
(12, 'Je vais rencontrer', 0),
(13, 'La chaussee va etre retrecie par la droite', 1),
(14, 'Ce panneau est un panneau de', 0),
(15, 'Je depasse immédiatement', 1),
(16, 'Sur cette chaussee je me place', 1),
(17, 'En prenant à droite, je quitte', 0),
(18, 'La rue en face est à sens unique', 0),
(19, 'Je passe', 1),
(20, 'Dans cette situation', 0);
-- --------------------------------------------------------

--
-- Structure de la table `reponses`
--

DROP TABLE IF EXISTS `reponses`;
CREATE TABLE IF NOT EXISTS `reponses` (
`idr` int(3) NOT NULL AUTO_INCREMENT,
`idq` int(3) NOT NULL,
`libeller` varchar(255) NOT NULL,
`verite` tinyint(1) NOT NULL,
PRIMARY KEY (`idr`)
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponses`
--

INSERT INTO `reponses` (`idr`, `idq`, `libeller`, `verite`) VALUES
(6, 2, 'Oui', 0),
(5, 2, 'Non', 1),
(4, 1, 'Oui', 0),
(2, 1, 'Non', 1),
(9, 3, 'Je passe', 1),
(10, 3, 'Je m arrete', 0),
(15, 4, 'Non', 0),
(16, 4, 'Oui', 1),
(17, 5, 'Non', 1),
(18, 5, 'Oui', 0),
(21, 6, 'Non', 1),
(22, 6, 'Oui', 0),
(25, 7, 'Oui', 0),
(26, 7, 'Non', 1),
(29, 8, 'LA PREMIERE SORTIE', 1),
(30, 8, 'LA DEUXIEME SORTIE', 0),
(35, 9, 'JE PASSE AVANT LA VOITURE ROUGE', 1),
(36, 9, 'JE PASSE APRES LA VOITURE ROUGE', 0),
(39, 10, 'JE DIMINUE MA DISTANCE DE SECURITE', 0),
(40, 10, 'J AUGMENTE MA DISTANCE DE SECURITE', 1),
(43, 11, 'Oui', 1),
(44, 11, 'Non', 0),
(45, 12, 'DES ENFANTS', 0),
(46, 12, 'UNE DESCENTE DANGEREUSE', 1),
(49, 13, 'Non', 1),
(50, 13, 'Oui', 0),
(55, 14, 'DANGER', 1),
(56, 14, 'INTERDICTION', 0),
(59, 15, 'Oui', 0),
(60, 15, 'Non', 1),
(61, 16, 'le long de la ligne mediane', 0),
(62, 16, 'le long de la bande cyclable', 1),
(63, 16, 'peu importe', 0),
(65, 17, 'Une autoroute', 1),
(66, 17, 'Une route a acces reglemente', 0),
(67, 17, 'Une route prioritaire', 0),
(69, 18, 'Oui', 0),
(71, 18, 'Non', 1),
(74, 19, 'avant la voiture rouge', 1),
(75, 19, 'apres la voiture rouge', 0),
(79, 20, 'JE PASSE ', 0),
(80, 20, 'JE M ARRETE', 1);

-- --------------------------------------------------------

--
-- Structure de la table `resultat`
--

DROP TABLE IF EXISTS `resultat`;
CREATE TABLE IF NOT EXISTS `resultat` (
`IdE` int(3) NOT NULL,
`IdSC` int(3) NOT NULL,
PRIMARY KEY (`IdE`,`IdSC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `resultat2`
--

DROP TABLE IF EXISTS `resultat2`;
CREATE TABLE IF NOT EXISTS `resultat2` (
`IdE` int(3) NOT NULL,
`IdP` int(3) NOT NULL,
PRIMARY KEY (`IdE`,`IdP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salles`
--

DROP TABLE IF EXISTS `salles`;
CREATE TABLE IF NOT EXISTS `salles` (
`idS` int(3) NOT NULL,
`nomS` varchar(25) DEFAULT NULL,
`nbP` int(3) DEFAULT NULL,
PRIMARY KEY (`idS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sessioncode`
--

DROP TABLE IF EXISTS `sessioncode`;
CREATE TABLE IF NOT EXISTS `sessioncode` (
`IdSC` int(3) NOT NULL,
`dateSC` date DEFAULT NULL,
`HeureDSC` date DEFAULT NULL,
`HeureFSC` date DEFAULT NULL,
PRIMARY KEY (`IdSC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `suit`
--

DROP TABLE IF EXISTS `suit`;
CREATE TABLE IF NOT EXISTS `suit` (
`IdE` int(3) NOT NULL,
`IdCond` int(3) NOT NULL,
PRIMARY KEY (`IdE`,`IdCond`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `suit2`
--

DROP TABLE IF EXISTS `suit2`;
CREATE TABLE IF NOT EXISTS `suit2` (
`IdE` int(3) NOT NULL,
`IdCode` int(3) NOT NULL,
PRIMARY KEY (`IdE`,`IdCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
`idu` int(10) NOT NULL AUTO_INCREMENT,
`nom` varchar(25) NOT NULL,
`prenom` varchar(25) NOT NULL,
`mail` varchar(25) NOT NULL,
`login` varchar(25) NOT NULL,
`mdp` varchar(25) NOT NULL,
`niveau` int(11) DEFAULT '0',
PRIMARY KEY (`idu`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`idu`, `nom`, `prenom`, `mail`, `login`, `mdp`, `niveau`) VALUES
(1, 'Panini', 'Henri', '', 'admin', 'admin', 0),
(2, 'admin', 'admin', 'admin@mail.com', 'admin', 'admin', 1),
(3, 'Ponpon', 'Fleure', 'fleure@mail.com', 'Ponce', 'azertyuiop', 0),
(4, 'kaye', 'hubert', 'kayeromy@gmail.com', 'KAYE', '1234', 0),
(5, 'killiane', 'kaye', 'killiane@gmail.com', 'killiane', '1234', 0),
(6, 'pato', 'erik', 'erik@gmail.com', 'pato', '1234', 0),
(7, 'Guez', 'FRED', 'ad@mail.com', 'az', 'az', 0);

-- --------------------------------------------------------

--
-- Structure de la table `voiture`
--

DROP TABLE IF EXISTS `voiture`;
CREATE TABLE IF NOT EXISTS `voiture` (
`idV` int(3) NOT NULL,
`nomV` varchar(25) DEFAULT NULL,
`carburant` varchar(25) DEFAULT NULL,
`immatriculation` varchar(9) DEFAULT NULL,
`dateMiseEnCirculation` date DEFAULT NULL,
PRIMARY KEY (`idV`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
