<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plus d'infos</title>
</head>
<body> 
		  <!-- Ouverture du header -->
	<div data-role="page">
	<div data-role="header">
		<h1>Permis B</h1>
		<a id="bars-button" data-icon="bars" class="ui-btn-right" style="margin-top:10px;" href="Accueil.php">Accueil</a>
</div><!-- /header -->


		  <!-- Ici le contenu -->
	<div data-role="content">	
		<div class="container">
			<div class="row">

				<div class="span12">
					<h4> Permis B </h4>
					L'épreuve théorique générale ETG
					La formation au code général est obligatoire si : 
					La partie théorique ou code peut être passée à partir
					de 17 ans et demi. L’examen a lieu dans un centre regroupant 
					les candidats d’un secteur. Durant l’épreuve chaque candidat 
					est soumis à une série de 40 questions à choix multiples diffusées
					sous la forme d’un diaporama. Le déroulement de l’épreuve s’effectue 
					sous la surveillance d’un examinateur. Chaque question met en situation
					le candidat sur une problématique pouvant être rencontrée sur la route.
					Pour y répondre, vous disposez d’un boitier électronique composé d’un écran 
					et de 6 touches (validation, correction, A, B, C et D) L’obtention de l’examen 
					a lieu si vous ne faites pas plus de 5 erreurs. Le résultat, vous est donné à
					la fin de l’épreuve, directement sur place. Une fois la pratique obtenue, vous
					avez 3 ans pour passer l’épreuve pratique à partir de la date d’obtention pour 
					5 présentations à l’examen. Si une de ces deux conditions devait être dépassée,
					il vous faudrait repasser l’examen pratique. <p> <p>
				</div>

				<div class="span4"> 
					<h4>FORFAIT 1 :</h4><p>
					•	Forfait code tests illimités (validité 6 mois)<p>
					•	3 examens blancs de code<p>
					•	1 présentation examen théorique<p>
					•	20 heures de conduite<p>
					•	1 présentation examen pratique<p>
					•	1 livre de code de la route<p>
					•	1 livre interrogation examen pratique<p>
					Total : 1260 € TTC
				</div>

				<div class="span4">
					<h4>FORFAIT 2 :</h4><p>
					•	Forfait code tests illimités (validité 6 mois)<p>
					•	4 examens blancs de code<p>
					•	2 présentations examen théorique<p>
					•	30 heures de conduite*<p>
					•	1 présentation examen pratique<p>
					•	1 livre de code de la route<p>
					•	1 livre interrogation examen pratique<p>
					Total : 1840 € TTC
				</div>

				<div class="span4">
					<h4>FORFAIT 3 :</h4><p>
					•	Forfait code tests illimités (validité 6 mois)<p>
					•	5 examens blancs de code<p>
					•	2 présentations examen théorique<p>
					•	35 heures de conduite*<p>
					Total : 1450 € TTC 
				</div>
				
				<p> <p>
				<div class="span4">
				<p> <h4> Pièces à fournir : </h4>
					•	5 photos d’identité<p>
					•	CNI<p>
					•	Justificatif de domicile<p>
					•	Permis A (si détenteur)<p>
					•	JAPD (si moins de 25 ans)<p>
					•	ASSR 2 (si né après 1988)<p>
					•	4 Enveloppes Timbrées<p>
					•	2 Enveloppe A5 Timbrées<p>
				</p>
				</div>
		</div>
	</div>
</div>	
		  <!-- Fin du contenu -->



	
	<div data-role="footer">
		<h4> Tous droits réservés</h4>
	</div><!-- /footer -->
</div><!-- /page -->

</body>
</html>